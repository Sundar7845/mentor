<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    public function register(Request $request)
    {
        $validator = validator::make($request->all(), [
            'firstname' => 'required|min:3',
            'lastname' => 'required|min:3',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8',
            'phonenumber' => 'required|min:10|numeric',
            'fcm' => '',
            'userrole_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'error' => $validator->errors()], 400);
        }

        $user = User::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'password' => bcrypt($request->password),
            'phonenumber' => $request->phonenumber,
            'userrole_id' => $request->userrole_id
        ]);
        // $return['id'] = $user->id;
        // $return['firstname'] = $request->firstname;
        // $return['lastname'] = $request->lastname;
        // //$return['email'] = $request->email;
        // $return['password'] = $request->password;
        // $return['phonenumber'] = $request->phonenumber;
        // $return['fcm'] = $request->fcm;
        // $return['userrole_id'] = $request->userrole_id;

        $return = 'Registered Successfully';

        return response()->json(['status' => true, 'message' => $return], 200);
    }

    /**
     * Login Req
     */
    public function login(Request $request)
    {
        $validator = validator::make($request->all(), [

            'email' => 'required|email',
            'password' => 'required|min:6',
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'error' => $validator->errors()], 400);
        }


        $data = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if (auth()->attempt($data)) {
            $token = auth()->user()->createToken('mentor')->accessToken;
            $user_id = auth()->user()->id;
            $user_firstname = auth()->user()->firstname;
            $user_lastname = auth()->user()->lastname;
            $space = " ";
            $user_name = $user_firstname .$space. $user_lastname;
            $userrole_id = auth()->user()->userrole_id;
            $user_profile=url('/api/user/profile/images/'.$user_id);
            $fcm ="FHCL3PakoQ4u5hVt98YL_qZSwylP4xodHkJ4sLhK_k5n0Ke1IYYaSNDZ9rPFXryo9gjJxY5D6wqqK0RWw_z7aPUTPPvlEelqwGAlWNtruGgkVQStRBYhvbBGwbEv5Cmww6DskNZTWwndKSSMmCxp4w";

            $responseData['status']=true;
            $userCollection = array("id" => $user_id, "name" => $user_name, "user_profile" => $user_profile, "userrole_id" => $userrole_id, "token" => $token, "fcm_token" => $fcm );
            $responseData['data']=$userCollection;
            return response()->json($responseData, 200);
        } else {
            return response()->json(['status' => false, 'error' => 'Unauthorised'], 401);
        }
    }

    // public function userInfo()
    // {

    //     $user = auth()->user();

    //     return response()->json(['user' => $user], 200);
    // }
    public function createpassword(Request $request)
    {
        $validator = validator::make($request->all(), [
            'password' => 'required|min8',
            'confirmpassword' => 'required|samepassword'
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'error' => $validator->errors()], 400);
        }
    }
}
