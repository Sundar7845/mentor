<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\Post;
use App\Models\Postmedia;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $data = $request->all();

        $validator = Validator::make($data, [
            'title' => 'required|max:255',
            'comment' => 'required|max:255',
            'posted_by_id' => 'required',
            'company_id' => 'required',
            'post_type_id' => 'required',
            'media_type_id' => 'required',
            'media_url' => 'required',
        ]);
        
        if ($validator->fails()) {
            $responseData['status']=false;
            $Error = $validator->errors();
            $responseData['error']=$Error;
            return response()->json($responseData);
        }
        
        $file = $request->file('media_url');
        $input['media_url'] = time() . '.' . $file->getClientOriginalExtension();
        $destinationPath = storage_path('public/post_media/');
        $file->move($destinationPath, $input['media_url']);
       
        $post = new Post();

        $post->title = $data['title'];
        $post->comment = $data['comment'];
        $post->posted_by_id = $data['posted_by_id'];
        $post->company_id = $data['company_id'];
        $post->post_type_id = $data['post_type_id'];
        $post->save();

        $post_media = new Postmedia();
        $post_media->post_id = $post->id;
        $post_media->media_type_id = $data['media_type_id'];
        $post_media->media_url = $input['media_url'];
        $post_media->save();
        
        $media = url('/api/post/media/' . $post_media->post_id);
                
        $responseData['status']=true;
        $postCollection = array("title" => $data['title'], "comment" => $data['comment'], "posted_by_id" => $data['posted_by_id'], "company_id" => $data['company_id'], "post_type_id" => $data['post_type_id'], "post_id" => $post->id, "media_type_id" => $data['media_type_id'], "media_url" => $media);
        $responseData['data']=$postCollection;
        return response()->json($responseData);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
      /*  $data = $request->all();

        $validator = Validator::make($data, [
            'title' => 'required|max:255',
            'comment' => 'required|max:255',
            'posted_by_id' => 'required',
            'company_id' => 'required',
            'post_type_id' => 'required',
            'media_type_id' => 'required',
            'media_url' => 'required',
        ]);
        
        if ($validator->fails()) {
            $responseData['status']=false;
            $Error = $validator->errors();
            $responseData['error']=$Error;
            return response()->json($responseData);
        }
        
        $file = $request->file('media_url');
        $input['media_url'] = time() . '.' . $file->getClientOriginalExtension();
        $destinationPath = storage_path('public/post_media/');
        $file->move($destinationPath, $input['media_url']);
       
        Post::whereid($id)->update($data);

        Postmedia::wherepost_id($id)->update($data);        
        $media = url('/api/post/media/' . $id);
                
        $responseData['status']=true;
        $postCollection = array("title" => $data['title'], "comment" => $data['comment'], "posted_by_id" => $data['posted_by_id'], "company_id" => $data['company_id'], "post_type_id" => $data['post_type_id'], "post_id" => $post->id, "media_type_id" => $data['media_type_id'], "media_url" => $media);
        $responseData['data']=$postCollection;
        return response()->json($responseData);   */
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
